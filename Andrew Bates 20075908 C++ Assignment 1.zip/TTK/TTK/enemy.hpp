#ifndef ENEMY_HPP
#define ENEMY_HPP


class enemy
{
    public:
        enemy();
        virtual ~enemy();

    protected:

    private:
};

#endif // ENEMY_HPP
