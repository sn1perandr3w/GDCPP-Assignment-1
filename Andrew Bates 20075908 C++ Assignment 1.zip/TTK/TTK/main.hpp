#ifndef MAIN_HPP
#define MAIN_HPP


using namespace sf;

int createBackground(VertexArray& rVA, IntRect arena);

#endif // MAIN_HPP
