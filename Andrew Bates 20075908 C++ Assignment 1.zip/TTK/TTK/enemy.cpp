#include "enemy.hpp"

enemy::enemy()
{
    //ctor
}

enemy::~enemy()
{
    //dtor
}
