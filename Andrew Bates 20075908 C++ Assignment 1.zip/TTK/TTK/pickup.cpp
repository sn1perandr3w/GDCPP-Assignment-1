#include "pickup.hpp"

pickup::pickup()
{
    //ctor
}

pickup::~pickup()
{
    //dtor
}
