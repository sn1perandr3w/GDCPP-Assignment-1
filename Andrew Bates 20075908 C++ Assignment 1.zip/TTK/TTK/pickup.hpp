#ifndef PICKUP_HPP
#define PICKUP_HPP


class pickup
{
    public:
        pickup();
        virtual ~pickup();

    protected:

    private:
};

#endif // PICKUP_HPP
